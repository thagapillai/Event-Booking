package com.ucetthaga.eventbookings;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class DataService {

	public static Connection getConnection(String connectString) {

		Connection conn = null;

		try {
			// Getting Connection with data
			conn = DriverManager.getConnection(connectString);
			System.out.println("Connection to SQLite has been established. Connection String: " + connectString);
			createEventsTable(conn);
			return conn;

		} catch (SQLException e) {
			e.printStackTrace();
			return conn;
		}
	}

	public static Boolean createEventsTable(Connection connection) {

		Statement stmt = null;

		String sql = "CREATE TABLE IF NOT EXISTS events (\n" + "ID	INTEGER NOT NULL UNIQUE,\n"
				+ "NAME	TEXT NOT NULL,\n" + "FROM_DATE	TEXT NOT NULL,\n" + "TO_DATE	TEXT NOT NULL,\n"
				+ "FROM_TIME	TEXT NOT NULL,\n" + "TO_TIME	TEXT NOT NULL,\n" + "LOCATION	TEXT NOT NULL,\n"
				+ "MOBILE_NUMBER	NUMERIC NOT NULL,\n" + "RATE	NUMERIC,\n" + "ACTIVE_FLAG	INTEGER NOT NULL,\n"
				+ "PRIMARY KEY(ID AUTOINCREMENT)\n)";

		try {
			stmt = connection.createStatement();
			stmt.execute(sql);
			System.out.println("Events table created or already exists...");
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public static void insertIntoEventsTable(Connection connection, String NAME, String FROM_DATE, String TO_DATE,
			String FROM_TIME, String TO_TIME, String LOCATION, String MOBILE_NUMBER, double RATE, int ACTIVE_FLAG) {

		String sql = "INSERT INTO events (NAME, FROM_DATE,TO_DATE,FROM_TIME,TO_TIME,LOCATION,MOBILE_NUMBER,RATE,ACTIVE_FLAG) VALUES (?,?,?,?,?,?,?,?,?)";

		try {
			PreparedStatement pstmt = connection.prepareStatement(sql);
			pstmt.setString(1, NAME);
			pstmt.setString(2, FROM_DATE);
			pstmt.setString(3, TO_DATE);
			pstmt.setString(4, FROM_TIME);
			pstmt.setString(5, TO_TIME);
			pstmt.setString(6, LOCATION);
			pstmt.setString(7, MOBILE_NUMBER);
			pstmt.setDouble(8, RATE);
			pstmt.setInt(9, ACTIVE_FLAG);

			pstmt.executeUpdate();
			System.out.println("Date Updated into events Table...");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
