package com.ucetthaga.eventbookings;

import java.sql.Connection;

public class App {
	public static void main(String[] args) {

		String currentDir = System.getProperty("user.dir");
		String filePath = currentDir + "\\events.db";
		String conString = "jdbc:sqlite:" + filePath;

		Connection connection = DataService.getConnection(conString);

		FrontEnd frontEnd = new FrontEnd();
		frontEnd.setConnection(connection);
		frontEnd.StartApp();
	}
}
