package com.ucetthaga.eventbooking;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import com.github.lgooddatepicker.components.DatePicker;
import com.github.lgooddatepicker.components.TimePicker;

public class FrontEnd {

	private static Connection connection;

	public void setConnection(Connection connection) {
		FrontEnd.connection = connection;
	}

	// Data Base Columns
	private String name;
	private String location;
	private String mobile;
	private String date;
	private String date_1;
	private String time;
	private String time_1;
	private double rate;

	private Statement st;
	private PreparedStatement pst;
	private ResultSet resultSet;
	private String ids;
	private String fromDateSelected;

	private JFrame frmEventBooking;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	private DatePicker datePicker;
	private DatePicker datePicker_1;
	private TimePicker timePicker;
	private TimePicker timePicker_1;

	private JComboBox<String> comboBoxFromDate;
	private JTextPane rateValue;
	private JPanel panel_2;

	/**
	 * Launch the application.
	 */
	public void StartApp() {
		getDatesByRefresh();

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrontEnd window = new FrontEnd();
					window.frmEventBooking.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Constructor
	 */
	public FrontEnd() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmEventBooking = new JFrame();
		frmEventBooking.setTitle("Event Booking - Thagapillai");
		frmEventBooking.setBounds(100, 100, 573, 606);
		frmEventBooking.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmEventBooking.getContentPane().setLayout(null);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setToolTipText("");
		tabbedPane.setBounds(13, 11, 534, 514);
		frmEventBooking.getContentPane().add(tabbedPane);

		/*
		 * #############################################################################
		 * TAB 1 (Booking Form)
		 * #############################################################################
		 * 
		 */

		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Booking Form", null, panel_1, null);
		panel_1.setLayout(null);

		JPanel Header = new JPanel();
		Header.setBounds(0, 0, 526, 120);
		Header.setLayout(null);
		panel_1.add(Header);

		JLabel lblNewLabel = new JLabel("Logu Events");
		lblNewLabel.setFont(new Font("Pristina", Font.BOLD, 30));
		lblNewLabel.setBounds(204, 11, 139, 48);
		Header.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Book Camera for Events");
		lblNewLabel_1.setFont(new Font("Stencil", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(105, 47, 315, 35);
		Header.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Enter the below details");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(173, 93, 180, 25);
		Header.add(lblNewLabel_2);

		JPanel Main = new JPanel();
		Main.setBounds(0, 131, 526, 317);
		Main.setLayout(null);
		Main.setBorder(new TitledBorder(

				new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)),

				" Fill the form ", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.add(Main);

		JPanel Form = new JPanel();
		Form.setLayout(null);
		Form.setBounds(10, 24, 506, 172);
		Main.add(Form);

		JLabel NameLabel = new JLabel("Name");
		NameLabel.setBounds(27, 11, 46, 14);
		Form.add(NameLabel);

		JLabel DateLabel = new JLabel("Date");
		DateLabel.setBounds(27, 43, 46, 14);
		Form.add(DateLabel);

		JLabel TimeLabel = new JLabel("Time");
		TimeLabel.setBounds(27, 72, 46, 14);
		Form.add(TimeLabel);

		JLabel LocationLabel = new JLabel("Location");
		LocationLabel.setBounds(26, 111, 63, 14);
		Form.add(LocationLabel);

		JLabel MobileLabel = new JLabel("Mobile Number");
		MobileLabel.setBounds(27, 136, 89, 14);
		Form.add(MobileLabel);

		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(126, 8, 334, 20);
		Form.add(textField);

		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(126, 108, 334, 20);
		Form.add(textField_1);

		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(126, 133, 334, 20);
		Form.add(textField_2);

		datePicker = new DatePicker();
		datePicker.setBounds(126, 34, 155, 29);
		Form.add(datePicker);

		datePicker_1 = new DatePicker();
		datePicker_1.setBounds(312, 34, 155, 29);
		Form.add(datePicker_1);

		timePicker = new TimePicker();
		timePicker.setBounds(126, 68, 155, 29);
		Form.add(timePicker);

		timePicker_1 = new TimePicker();
		timePicker_1.setBounds(312, 68, 155, 29);
		Form.add(timePicker_1);

		JLabel lblNewLabel_3 = new JLabel("From");
		lblNewLabel_3.setBounds(83, 36, 33, 50);
		Form.add(lblNewLabel_3);

		JLabel lblNewLabel_3_1 = new JLabel("To");
		lblNewLabel_3_1.setBounds(291, 36, 24, 50);
		Form.add(lblNewLabel_3_1);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(10, 207, 506, 47);
		Main.add(panel);

		JLabel lblNewLabel_4 = new JLabel("Calculated Rate");
		lblNewLabel_4.setBounds(39, 11, 111, 25);
		panel.add(lblNewLabel_4);

		rateValue = new JTextPane();
		rateValue.setBounds(144, 11, 130, 25);
		panel.add(rateValue);

		// Calculate Button and its Action

		JButton calculateBtn = new JButton("Calculate Rate");
		calculateBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showRate();
			}
		});
		calculateBtn.setBounds(323, 12, 166, 23);
		panel.add(calculateBtn);

		// Book Button and its Action

		JButton bookBtn = new JButton("Book");
		bookBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insert();
			}
		});
		bookBtn.setFont(new Font("Tahoma", Font.BOLD, 20));
		bookBtn.setBounds(209, 273, 108, 33);
		Main.add(bookBtn);

		/*
		 * #############################################################################
		 * TAB 2 (Events Details page)
		 * #############################################################################
		 * 
		 */

		panel_2 = new JPanel();
		tabbedPane.addTab("View Events", null, panel_2, null);
		panel_2.setLayout(null);

		JPanel Header_1 = new JPanel();
		Header_1.setLayout(null);
		Header_1.setBounds(0, 0, 526, 120);
		panel_2.add(Header_1);

		JLabel lblNewLabel_6 = new JLabel("Logu Events");
		lblNewLabel_6.setFont(new Font("Pristina", Font.BOLD, 30));
		lblNewLabel_6.setBounds(193, 0, 139, 48);
		Header_1.add(lblNewLabel_6);

		JLabel lblNewLabel_1_1 = new JLabel("Book Camera for your Events");
		lblNewLabel_1_1.setFont(new Font("Stencil", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(105, 47, 315, 35);
		Header_1.add(lblNewLabel_1_1);

		JLabel lblNewLabel_2_1 = new JLabel("Our Upcoming Events");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_2_1.setBounds(173, 93, 180, 25);
		Header_1.add(lblNewLabel_2_1);

		JLabel lblNewLabel_5 = new JLabel("Select From Date");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_5.setBounds(40, 150, 164, 34);
		panel_2.add(lblNewLabel_5);

		// Fetch Button and its action

		JButton btnNewButton = new JButton("FETCH");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ShowTable();
			}
		});
		btnNewButton.setBounds(205, 219, 118, 43);
		panel_2.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("↻");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getDatesByRefresh();
			}
		});
		btnNewButton_1.setBounds(436, 156, 72, 26);
		panel_2.add(btnNewButton_1);

	}

	/**
	 * Getting From Dates and showing on Combo Box
	 */
	private void getDatesByRefresh() {

		try {
			st = connection.createStatement();
			resultSet = st.executeQuery("select distinct FROM_DATE from events");

			DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>();

			while (resultSet.next()) {
				ids = resultSet.getString(1);
				model.addElement(ids);
			}

			if (comboBoxFromDate != null) {
				comboBoxFromDate.removeAll();
				comboBoxFromDate.setModel(model);
			} else {
				comboBoxFromDate = new JComboBox<>(model);
			}
			comboBoxFromDate.setBounds(236, 156, 194, 26);
			panel_2.add(comboBoxFromDate);

			st.close();
			resultSet.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Get the dates and calculate the total minutes
	 */
	private long getDatesAndMinDiff() {
		String dateTimeString1 = datePicker.getDate().toString() + " " + timePicker.getTime().toString();
		String dateTimeString2 = datePicker_1.getDate().toString() + " " + timePicker_1.getTime().toString();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

		LocalDateTime dateTime1 = LocalDateTime.parse(dateTimeString1, formatter);
		LocalDateTime dateTime2 = LocalDateTime.parse(dateTimeString2, formatter);

		long diffInMinutes = java.time.Duration.between(dateTime1, dateTime2).toMinutes();

		System.out.println("Total Minutes : " + diffInMinutes);

		return diffInMinutes;

	}

	/**
	 * Get the total minutes as parameter and return the Calculated rate
	 */
	private double calculateRate(long minDiff) {
		/*
		 * per hour 200rs 60min, per day 2500rs 1440min, per month 20000rs 43200min
		 */

		if ((30 <= minDiff) && (minDiff <= 720)) {
			double hr = Math.ceil(minDiff / 60.0);
			System.out.println("Calculated amount: " + hr * 200);
			return (hr * 200);

		} else if ((720 < minDiff) && (minDiff <= 11520)) {
			double day = Math.ceil(minDiff / 1440.0);
			System.out.println("Calculated amount: " + day * 2500);
			return (day * 2500);

		} else if (11520 < minDiff) {
			double mnth = Math.ceil(minDiff / 43200.0);
			System.out.println("Calculated amount: " + mnth * 20000);
			return (mnth * 20000);
		} else {
			return 0;
		}
	}

	/**
	 * Calculate and Show the rate.
	 */
	private void showRate() {
		rate = calculateRate(getDatesAndMinDiff());
		rateValue.setText("Rs. " + rate);

	}

	/**
	 * Get the Data from form and insert into DateBase.
	 */
	private void insert() {

		name = textField.getText();
		date = datePicker.getDate().toString();
		date_1 = datePicker_1.getDate().toString();
		time = timePicker.getTime().toString();
		time_1 = timePicker_1.getTime().toString();
		location = textField_1.getText();
		mobile = textField_2.getText();
		DataService.insertIntoEventsTable(connection, name, date, date_1, time, time_1, location, mobile, rate, 1);

		textField.setText("");
		textField_1.setText("");
		textField_2.setText("");
		datePicker.setText("");
		datePicker_1.setText("");
		timePicker.setText("");
		timePicker_1.setText("");
		rateValue.setText("");

		JOptionPane.showMessageDialog(frmEventBooking, "Event added into the Database.");

	}

	/**
	 * To show the Fetched data in separate window
	 */
	private void ShowTable() {
		String[] columnNames = { "id", "Name", "From Date", "To Date", "From Time", "To Time", "Location", "Mobile",
				"Rate", "IsActive" };
		JFrame frame1 = new JFrame("Database Search Result");

		frame1.getContentPane().setLayout(new BorderLayout());

		DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(columnNames);

		JTable table = new JTable();
		table.setModel(model);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.setFillsViewportHeight(true);
		JScrollPane scroll = new JScrollPane(table);
		scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		fromDateSelected = (String) comboBoxFromDate.getSelectedItem();

		String Id = "";
		String Name = "";
		String FromDate = "";
		String ToDate = "";
		String FromTime = "";
		String ToTime = "";
		String Mobile = "";
		String Location = "";
		String Rate = "";
		String isActive = "";
		try {
			pst = connection.prepareStatement("select * from events where FROM_DATE='" + fromDateSelected + "'");
			ResultSet resultSet = pst.executeQuery();
			int i = 0;

			while (resultSet.next()) {
				Id = resultSet.getString("ID");
				Name = resultSet.getString("NAME");
				FromDate = resultSet.getString("FROM_DATE");
				ToDate = resultSet.getString("TO_DATE");
				FromTime = resultSet.getString("FROM_TIME");
				ToTime = resultSet.getString("TO_TIME");
				Mobile = resultSet.getString("MOBILE_NUMBER");
				Rate = resultSet.getString("RATE");
				Location = resultSet.getString("LOCATION");
				isActive = resultSet.getString("ACTIVE_FLAG");

				if (isActive.equalsIgnoreCase("1")) {
					isActive = "true";
				} else {
					isActive = "false";
				}

				model.addRow(new Object[] { Id, Name, FromDate, ToDate, FromTime, ToTime, Location, Mobile, Rate,
						isActive });
				i++;
			}
			if (i < 1) {
				JOptionPane.showMessageDialog(null, "No Record Found", "Error", JOptionPane.ERROR_MESSAGE);
			}
			if (i == 1) {
				System.out.println(i + " Record Found");
			} else {
				System.out.println(i + " Records Found");
			}
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
		frame1.getContentPane().add(scroll);
		frame1.setVisible(true);
		frame1.setSize(400, 300);

	}
}
